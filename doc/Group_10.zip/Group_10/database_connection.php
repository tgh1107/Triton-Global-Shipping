<?php 

//database_connection.php

$connect = new PDO("mysql:host=localhost;dbname=jc561664_ebusinessa2", "jc561664", "Password664");

?>